# currency-converter
 Simple currency converter web app using Exchange Rate API 
  Note: Change API_KEY variable with your own from <a href="https://www.exchangerate-api.com/">https://www.exchangerate-api.com/</a><br>
  in /js/main.js file
  ```
  API_KEY = 'YOUR_OWN_API_KEY';
